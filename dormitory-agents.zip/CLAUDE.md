# ระบบจัดการหอพัก — Team Configuration

## โปรเจกต์
ระบบ SaaS จัดการหอพักสำหรับเจ้าของหอพักไทย รองรับทุกขนาดตั้งแต่หอเล็ก 10 ห้อง จนถึงหอใหญ่ 500+ ห้อง

---

## AI Team Configuration

### ทีมงาน

| Agent | บทบาท | Model | ใช้เมื่อ |
|-------|--------|-------|---------|
| `@agent-md-orchestrator` | MD / หัวหน้าโปรเจกต์ | Opus | เริ่ม feature ใหม่, sprint planning, resolve conflict |
| `@agent-dev` | นักพัฒนา | Sonnet | Implement, แก้ bug, code review |
| `@agent-tester` | QA | Sonnet | ทดสอบ feature, regression test |
| `@agent-marketing` | การตลาด | Sonnet | Pitch ลูกค้า, เตรียม demo |
| `@agent-seo` | SEO/โปรโมท | Sonnet | Content, keyword, landing page |
| `@agent-customer-ca` | Persona CA | Haiku | Simulate ลูกค้าเล็ก |
| `@agent-customer-cb` | Persona CB | Haiku | Simulate ลูกค้ากลาง |
| `@agent-customer-cc` | Persona CC | Haiku | Simulate ลูกค้าใหญ่ |

---

## Sub-Agent Routing Rules

### Parallel dispatch (รันพร้อมกัน)
- `@agent-customer-ca` + `@agent-customer-cb` + `@agent-customer-cc` — pitch session เสมอ
- Frontend task + Backend task ที่ไม่ depend กัน
- SEO content + Marketing deck สำหรับ launch

### Sequential dispatch (รันต่อกัน)
```
Dev implement → Tester ตรวจ → ถ้า pass → MD approve
                             → ถ้า fail → Dev แก้ → Tester ยืนยันซ้ำ
```

### Agent Team (ต้องคุยกันแบบ real-time)
```
Marketing pitch → CA + CB + CC respond พร้อมกัน → Marketing สรุป → MD รับ action items
```

---

## Coding Standards

### Tech Stack
- Next.js 14+ (App Router) + TypeScript
- Tailwind CSS + shadcn/ui
- PostgreSQL + Prisma
- NextAuth.js
- Supabase Storage

### กฎเหล็ก
- TypeScript strict mode เสมอ — ห้าม `any`
- Zod validation ทุก API input
- ทุก feature ต้องผ่าน Tester ก่อน merge
- Comment business logic เป็นภาษาไทย
- ทุก PR ต้องมี test case

### โครงสร้าง DB หลัก
```
Organization (เจ้าของ)
  └── Building (ตึก)
        └── Room (ห้อง)
              └── Tenant (ผู้เช่า)
                    └── Bill (บิล)
```

---

## Workflow

### เพิ่ม Feature ใหม่
```
1. บอก MD requirement
2. MD วางแผน + แตก task
3. Dev implement
4. Tester ตรวจ
5. MD approve + deploy
```

### Pitch ลูกค้า
```
1. บอก Marketing ว่าจะ pitch feature อะไร
2. Marketing เตรียม pitch
3. Spawn CA + CB + CC (Agent Team)
4. Marketing present → ลูกค้า react
5. Marketing สรุป feedback → MD
6. MD สั่ง Dev ปรับปรุง
```
